<?php
    use Illuminate\Support\Str;
?>

<nav class="navbar navbar-expand-lg flex-column">
    <ul id="side-nav" class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">ダッシュボード</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.artist') ? 'active' : ''); ?>" href="<?php echo e(route('admin.artist')); ?>">アーティスト管理</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.offer') ? 'active' : ''); ?>" href="<?php echo e(route('admin.offer')); ?>">案件管理</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.inquiry') ? 'active' : ''); ?>" href="<?php echo e(route('admin.inquiry')); ?>">問合せ管理</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.message') ? 'active' : ''); ?>" href="<?php echo e(route('admin.message')); ?>">メッセージ管理</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.catalogue') ? 'active' : ''); ?>" href="<?php echo e(route('admin.catalogue')); ?>">カタログ作成</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.sales') ? 'active' : ''); ?>" href="<?php echo e(route('admin.sales')); ?>">売買管理</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.notice') ? 'active' : ''); ?>" href="<?php echo e(route('admin.notice')); ?>">サイトお知らせ</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Str::startsWith(Route::currentRouteName(), 'admin.page') ? 'active' : ''); ?>" href="<?php echo e(route('admin.page')); ?>">ページ管理</a>
        </li>
    </ul>
</nav>

<?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/components/nav_admin.blade.php ENDPATH**/ ?>