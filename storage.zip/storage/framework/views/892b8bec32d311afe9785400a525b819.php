<?php $__env->startPush('description'); ?>
    //
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content_wrapper">
        <h2 class="page-title" id="page_title">案件管理</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/admin/offer.blade.php ENDPATH**/ ?>