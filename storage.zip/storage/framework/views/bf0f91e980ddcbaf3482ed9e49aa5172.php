<header id="header">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
                <?php echo e(config('app.name', 'Mirai Artist Club')); ?>

            </a>
            <div>
                <!-- 右側に配置するメニューやユーザー情報 -->
                <ul class="nav admin_header_nav">
                    <li class="nav-item">
                        login as: <?php echo e(Auth::guard('admin')->user()->name); ?>

                    </li>
                    <li class="nav-item position-relative">
                        <a class="nav-link" href="#" title="通 知" id="notification-icon">
                            <i class="fas fa-bell"></i>
                        </a>
                        <span class="badge badge-pill badge-danger notification-badge">
                            <?php echo e($notifications->count()); ?>

                        </span>

                        <!-- ドロップダウンメッセージ -->
                        <div class="dropdown-menu notifications-dropdown" id="notifications-dropdown">
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $data = json_decode($notification->data, true);
                                ?>
                                <a class="dropdown-item" href="#">
                                    <?php echo e($data['artist_name'] ?? '不明なアーティスト'); ?>さんから<?php echo e($data['message'] ?? '未対応の通知があります。'); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.setting')); ?>" title="設 定"><i class="fas fa-wrench"></i></a>
                    </li><li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.logout')); ?>" title="ログアウト"><i class="fas fa-sign-out-alt"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/components/header_admin.blade.php ENDPATH**/ ?>