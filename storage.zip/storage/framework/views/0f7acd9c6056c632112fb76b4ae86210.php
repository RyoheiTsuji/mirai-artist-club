<?php $__env->startSection('content'); ?>
    <h1>管理画面ダッシュボード</h1>
    <p>作家登録人数：<?php echo e($artistCount); ?></p>
    <p>作風登録数：<?php echo e($tagCount); ?></p>
    <p>管理人数：<?php echo e($adminCount); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>