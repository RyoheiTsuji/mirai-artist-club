<?php $__env->startSection('content'); ?>
    <h1>メッセージ管理</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/admin/message.blade.php ENDPATH**/ ?>