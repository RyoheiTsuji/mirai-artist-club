<?php $__env->startSection('content'); ?>
    <div id="content_wrapper">
        <h2 class="page-title" id="page_title">設定画面</h2>
        <main class="row mt-5">
            <div class="col-6">
                <div class="settingMenu">
                    <div>
                    <h3>管理者登録</h3>
                    <p>管理者を追加します。名前とパスワードとメールアドレスを入力し登録してください。</p>
                    <p>現在の管理者数: <?php echo e($adminCount); ?></p>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('admin.RegAdmin')); ?>" method="post" title="新規管理者登録">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name">名前</label>
                            <input name="name" id="name" type="text" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="email">メールアドレス</label>
                            <input name="email" id="email" type="email" class="form-control" required>
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="password">パスワード</label>
                            <input name="password" id="password" type="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password_confirmation">パスワード確認</label>
                            <input name="password_confirmation" id="password_confirmation" class="form-control" type="password" required>
                        </div>

                        <button type="submit" class="btn btn-primary">登録</button>
                    </form>
                    </div>
                    <div class="mt-4 row">
                        <h3>管理者削除</h3>
                        <form action="<?php echo e(route('admin.deleteAdmin')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mt-3 mb-2 col-6">
                                    <input type="checkbox" name="admin_id[]" value="<?php echo e($admin->id); ?>">
                                    <label><?php echo e($admin->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-danger mt-2">削除</button>
                        </form>
                    </div>

                </div>
            </div>
            <div class="col-6">
                <div>
                    <div class="settingMenu">
                        <h3>作風管理</h3>
                        <p>登録済みの作風の数: <?php echo e($tagCount); ?></p>
                        <p>
                            作風の管理をします。<br>
                            作風とコメントの登録・削除、順番の並べ替えができます。
                        </p>

                        <a href="<?php echo e(route('tags.create')); ?>" title="タグの管理画面へすすむ" >>>タグ管理</a>
                    </div>
                    <div class="settingMenu">
                        <h3>SEO設定</h3>
                        <p>管理画面、マイページ関連以外のページ(固定ページ含む)のSEO設定を行います。</p>
                        <p>この設定画面ではheadタグ内のtitle,descriptionなどのmetaタグをページごとに編集します。</p>
                        <a href="#" title="SEO設定へすすむ" >>>SEO設定</a>
                    </div>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/admin/setting.blade.php ENDPATH**/ ?>