<header id="header">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
                <?php echo e(config('app.name', 'Mirai Artist Club')); ?>

            </a>
        </div>
    </div>
</header>
<?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/components/header.blade.php ENDPATH**/ ?>