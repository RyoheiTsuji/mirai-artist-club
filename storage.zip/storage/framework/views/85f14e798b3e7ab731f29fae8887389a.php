<?php $__env->startPush('description'); ?>
    //
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('membersChart').getContext('2d');

            // Laravelコントローラから渡されたデータをJavaScriptに渡す
            var labels = Object.values(<?php echo json_encode($months->toArray(), 15, 512) ?>);
            var data = Object.values(<?php echo json_encode($chartData->toArray(), 15, 512) ?>);
            var chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels, // X軸のラベル（年月）
                    datasets: [{
                        label: '会員数の推移',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        data: data, // Y軸のデータ
                        fill: false,
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            reverse: true // X軸を反転させる
                        },
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content_wrapper">
        <h2 class="page-title" id="page_title">アーティスト管理</h2>
        <main class="row">
            <div class="col-6">
                <h3 class="content-title">お知らせ</h3>
                <ul>
                    <li><a href="#">未対応の"作品承認"があります</a></li>
                    <li><a href="#">未対応の"購入申込"があります</a></li>
                    <li><a href="#">未対応の"作家問い合わせ"があります</a></li>
                    <li><a href="#">”作家問い合わせ”に返信があります</a></li>
                </ul>
            </div>
            <div class="col-6">
                <h3 class="content-title">統計情報</h3>
                <canvas id="membersChart"></canvas>
            </div>

            <div class="col-12 row">
                <h3 class="content-title">登録作家一覧</h3>

                <div class="mb-3 mt-3 mb-5">
                    <h4 class="area-title" id="search_area">[検索エリア]</h4>
                    <form action="<?php echo e(route('admin.artist')); ?>" method="GET" class="row g-2">
                        <div class="col-md-3">
                            <input type="text" name="keyword" class="form-control" value="<?php echo e(request('keyword')); ?>" placeholder="キーワードで検索">
                        </div>
                        <div class="col-md-3">
                            <select name="tag_id" class="form-select">
                                <option value="">全てのタグ</option>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tag->id); ?>" <?php echo e(request('tag_id') == $tag->id ? 'selected' : ''); ?>><?php echo e($tag->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">絞り込む</button>
                            <a href="<?php echo e(request()->fullUrlWithQuery(['order' => 'asc'])); ?>" class="btn btn-link">昇順</a>
                            <a href="<?php echo e(request()->fullUrlWithQuery(['order' => 'desc'])); ?>" class="btn btn-link">降順</a>
                        </div>
                    </form>
                </div>

                <div class="d-flex flex-wrap">
                <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="artist_frame">
                        <img src="<?php echo e(asset('storage/' . $artist['photo_url'])); ?>" alt="<?php echo e($artist['name']); ?>" width="260">
                        <table>
                            <tr>
                                <th>名前</th>
                                <td><?php echo e($artist['name']); ?></td>
                                <th>年齢</th>
                                <td><?php echo e($artist['age']); ?></td>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <?php $__currentLoopData = $artist['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="tagname"><?php echo e($tag); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                                <th colspan="4">PR</th>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <?php echo e($artist['pr_statement']); ?>

                                </td>
                            </tr>
                        </table>
                        <div class="button-container">
                            <a href="<?php echo e(route('admin.artist.detail', ['id' => $artist['id']])); ?>" class="btn btn-primary full-width-btn">詳細ページ</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </main>

<!--    ヒントウィンドウセクション    -->
        <div id="hints_window">
            <span id="toggle_hint"><i class="fa-solid fa-circle-up"></i></span>
            <div id="hints_content">
                <h2>Hint Window</h2>
                <section class="hint_article" data-target="page_title" style="display:none">
                    このページでは作家に関する様々な管理を行えます。
                    <dl>
                        <dt>・作家検索：</dt><dd>登録されている作家を検索出来ます。</dd>
                        <dt>・作品承認：</dt><dd>作家が公開を希望する作品の承認ができます。</dd>
                        <dt>・メッセージ管理：</dt><dd>作家が公開を希望する作品の承認ができます。</dd>
                        <dt>・作品承認：</dt><dd>作家が公開を希望する作品の承認ができます。</dd>
                    </dl>
                </section>
                <section class="hint_article" data-target="membersChart" style="display:none">
                    <p>任意の集計可能な統計を出すことが出来ます。</p>
                    <p>現在は月ごとの会員登録数を折れ線グラフで出しています。</p>
                </section>
                <section class="hint_article" data-target="search_area" style="display:none">
                    <p>検索エリアです。</p>
                    <p>作家の検索ができます。</p>
                    <p>検索ロジックは、作家の全登録内容からキーワードで全件検索をあいまい検索してタグで絞り込みをかける流れです。</p>
                    <p>キーワードだけでもタグだけでも検索ができます。</p>
                </section>
            </div>
        </div>
<!--  ヒントウィンドウセクションここまで　-->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/admin/artist.blade.php ENDPATH**/ ?>