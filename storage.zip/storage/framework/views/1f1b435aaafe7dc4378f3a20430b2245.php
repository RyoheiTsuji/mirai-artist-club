<?php $__env->startSection('content'); ?>
    <h1 class="page_title">マイページ</h1>
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-6 col-md-6">
                <div class="card">
                    <h2 class="section_title">プロフィール</h2>
                    <div class="myPhoto">
                        <img src="<?php echo e(asset('storage/' . $artist['photo_url'])); ?> ?? '#' }}" alt="アー写">
                        <ul class="controlBox">
                            <li><i class="fa-solid fa-cloud-arrow-up"></i></li>
                            <li><i class="fa-solid fa-pen-to-square"></i></li>
                        </ul>
                    </div>
                    <dl class="artist_info">
                        <dt>作家名</dt>
                        <dd><?php echo e($artist->name); ?></dd>
                        <dt>作風</dt>
                        <dd></dd>
                        <dt>メールアドレス</dt>
                        <dd><?php echo e($artist->email); ?></dd>
                        <dt>住所</dt>
                        <dd>
                            〒<?php echo e($artist->postal_code ?? ''); ?><br>
                            <?php echo e($artist->address ?? '登録がありません'); ?>

                        </dd>
                        <dt>生年月日</dt>
                        <dd><?php echo e($artist->birthday ?? '登録がありません'); ?></dd>
                        <dt>電話番号</dt>
                        <dd><?php echo e($artist->phone_number ?? '登録がありません'); ?></dd>
                    </dl>
                    <dl class="artist_detail">
                        <dt>P R</dt>
                        <dd><?php echo e($artist->pr_statement ?? '登録がありません'); ?></dd>
                        <dt>バイオグラフィ</dt>
                        <dd><?php echo e($artist->bio ?? '登録がありません'); ?></dd>
                    </dl>
                    <p>ポートフォリオURL：<a href="<?php echo e(asset('storage/' . $artist['portfolio_pdf'])); ?> " class="btn btn-secondary">ダウンロード</a></p>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-6">
                <form action="<?php echo e(route('portfolio.upload')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="portfolio" class="form-label">ポートフォリオPDFをアップロード</label>
                        <input class="form-control" type="file" id="portfolio" name="portfolio" accept="application/pdf">
                    </div>
                    <button type="submit" class="btn btn-primary">アップロード</button>
                </form>
            </div>

            <div class="col-12 mt-4">
                <h2 class="section_title">作品一覧</h2>
                <?php if($artist->artworks->isEmpty()): ?>
                    <p>登録された作品がありません。</p>
                <?php else: ?>
                    <ul id="artwork_area" class="list-unstyled d-flex flex-row flex-wrap">
                        <?php $__currentLoopData = $artist->artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="">
                                <strong><?php echo e($artwork->title); ?></strong> (<?php echo e($artwork->year); ?>)<br>
                                <img src="<?php echo e(Storage::url($artwork->image_path)); ?>" alt="<?php echo e($artwork->title); ?>" style="max-width: 100px;">
                                <p><?php echo e($artwork->description); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_mypage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_mac\htdocs\mac\resources\views/mypage/mypage.blade.php ENDPATH**/ ?>